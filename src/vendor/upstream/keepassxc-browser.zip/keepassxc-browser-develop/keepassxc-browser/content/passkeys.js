'use strict';

(async () => {
    const PASSKEYS_NO_LOGINS_FOUND = 15;
    const PASSKEYS_ATTESTATION_NOT_SUPPORTED = 20;
    const PASSKEYS_CREDENTIAL_IS_EXCLUDED = 21;
    const PASSKEYS_REQUEST_CANCELED = 22;
    const PASSKEYS_INVALID_USER_VERIFICATION = 23;
    const PASSKEYS_EMPTY_PUBLIC_KEY = 24;
    const PASSKEYS_INVALID_URL_PROVIDED = 25;
    const PASSKEYS_ORIGIN_NOT_ALLOWED = 26;
    const PASSKEYS_DOMAIN_IS_NOT_VALID = 27;
    const PASSKEYS_DOMAIN_RPID_MISMATCH = 28;
    const PASSKEYS_NO_SUPPORTED_ALGORITHMS = 29;
    const PASSKEYS_WAIT_FOR_LIFETIMER = 30;
    const PASSKEYS_UNKNOWN_ERROR = 31;
    const PASSKEYS_INVALID_CHALLENGE = 32;
    const PASSKEYS_INVALID_USER_ID = 33;
    const PASSKEYS_EVAL_BY_CREDENTIAL_NOT_SUPPORTED = 34;
    const PASSKEYS_EVAL_BY_CREDENTIAL_NOT_EMPTY = 35;
    const PASSKEYS_EVAL_BY_CREDENTIAL_NOT_FOUND = 36;

    const kpxcStringToArrayBuffer = function(str) {
        const arr = Uint8Array.from(str, c => c.charCodeAt(0));
        return arr.buffer;
    };

    // From URL encoded base64 string to ArrayBuffer
    const kpxcBase64ToArrayBuffer = function(str) {
        return kpxcStringToArrayBuffer(window.atob(str?.replaceAll('-', '+').replaceAll('_', '/')));
    };

    // From ArrayBuffer to URL encoded base64 string
    const kpxcArrayBufferToBase64 = function(buf) {
        const str = [ ...new Uint8Array(buf) ].map(c => String.fromCharCode(c)).join('');
        return window.btoa(str).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
    };

    // Returns the PublicKeyCredential as JSON
    // See: https://w3c.github.io/webauthn/#dom-publickeycredential-tojson
    const kpxcPublicKeyCredentialJson = function (credential, publicKey) {
        const clientExtensionResults = credential.getClientExtensionResults();
        const type = credential.type;
        const authenticatorAttachment = credential.authenticatorAttachment;
        let response;

        if (credential.response instanceof AuthenticatorAttestationResponse) {
            const responsePublicKey = credential.response.getPublicKey();
            response = {
                clientDataJSON: publicKey.response.clientDataJSON,
                authenticatorData: publicKey.response.authenticatorData,
                transports: credential.response.getTransports(),
                publicKey: responsePublicKey ? kpxcArrayBufferToBase64(responsePublicKey) : null,
                publicKeyAlgorithm: credential.response.getPublicKeyAlgorithm(),
                attestationObject: publicKey.response.attestationObject,
            };
        }

        if (credential.response instanceof AuthenticatorAssertionResponse) {
            response = {
                clientDataJSON: publicKey.response.clientDataJSON,
                authenticatorData: publicKey.response.authenticatorData,
                signature: publicKey.response.signature,
                userHandle: publicKey.response?.userHandle || undefined,
            };
        }

        return {
            id: publicKey.id,
            rawId: publicKey.id,
            response,
            authenticatorAttachment,
            clientExtensionResults,
            type,
        };
    };

    // Wraps response to AuthenticatorAttestationResponse object
    const createAttestationResponse = function(publicKey) {
        const response = {
            attestationObject: kpxcBase64ToArrayBuffer(publicKey.response.attestationObject),
            clientDataJSON: kpxcBase64ToArrayBuffer(publicKey.response.clientDataJSON),
            getAuthenticatorData: () => kpxcBase64ToArrayBuffer(publicKey.response?.authenticatorData),
            getPublicKey: () =>
                publicKey.response?.publicKey ? kpxcBase64ToArrayBuffer(publicKey.response?.publicKey) : null,
            getPublicKeyAlgorithm: () => publicKey.response?.publicKeyAlgorithm,
            getTransports: () => [ 'internal' ]
        };

        const prfResponse = publicKey.response?.clientExtensionResults?.prf;
        if (prfResponse) {
            if (prfResponse?.results?.first) {
                response['clientExtensionResults'] =
                { prf: { results: { first: kpxcBase64ToArrayBuffer(prfResponse?.results?.first) } } };
            } else if (prfResponse?.enabled) {
                response['clientExtensionResults'] = { prf: prfResponse };
            }
        }

        return Object.setPrototypeOf(response, AuthenticatorAttestationResponse.prototype);
    };

    // Wraps response to AuthenticatorAssertionResponse object
    const createAssertionResponse = function(publicKey) {
        const response = {
            authenticatorData: kpxcBase64ToArrayBuffer(publicKey.response?.authenticatorData),
            clientDataJSON: kpxcBase64ToArrayBuffer(publicKey.response?.clientDataJSON),
            signature: kpxcBase64ToArrayBuffer(publicKey.response?.signature),
            userHandle: publicKey.response?.userHandle ? kpxcBase64ToArrayBuffer(publicKey.response?.userHandle) : null
        };

        const prfResponse = publicKey.response?.clientExtensionResults?.prf?.results?.first;
        if (prfResponse) {
            response['clientExtensionResults'] = { prf: { results: { first: kpxcBase64ToArrayBuffer(prfResponse) } } };
        }

        return Object.setPrototypeOf(response, AuthenticatorAssertionResponse.prototype);
    };

    // Wraps public key to PublicKeyCredential object
    const createPublicKeyCredential = function(publicKey) {
        const authenticatorResponse = publicKey?.response?.attestationObject
            ? createAttestationResponse(publicKey)
            : createAssertionResponse(publicKey);
        const clientExtensionResults =
            authenticatorResponse?.clientExtensionResults || publicKey?.response?.clientExtensionResults || {};
        const publicKeyCredential = {
            authenticatorAttachment: publicKey.authenticatorAttachment,
            id: publicKey.id,
            rawId: kpxcBase64ToArrayBuffer(publicKey.id),
            response: authenticatorResponse,
            type: publicKey.type,
            clientExtensionResults: () => clientExtensionResults,
            getClientExtensionResults: () => clientExtensionResults,
            toJSON: () => kpxcPublicKeyCredentialJson(publicKeyCredential, publicKey)
        };

        return Object.setPrototypeOf(publicKeyCredential, PublicKeyCredential.prototype);
    };

    /**
     * Posts a message to extension's content script and waits for response
     * @async
     * @param {object} request
     * @param {AbortSignal=} signal
     * @returns {Promise<object>}
     * @throws {unknown} if `AbortSignal`
     */
    const postMessageToExtension = function(request, signal) {
        return new Promise((resolve, reject) => {
            const ev = document;

            function abort() {
                // TODO: Use reject(signal?.reason) with WebAuthn 3
                reject(new DOMException(signal?.reason?.message || 'AbortError', 'AbortError'));
            }

            const listener = ((messageEvent) => {
                const handler = (msg) => {
                    if (msg && msg.type === 'kpxc-passkeys-response' && msg.detail) {
                        messageEvent.removeEventListener('kpxc-passkeys-response', listener);

                        if (msg.detail.errorCode === 'abort') {
                            return abort();
                        }
                        resolve(msg.detail);
                        return;
                    }
                };
                return handler;
            })(ev);

            if (signal instanceof AbortSignal) {
                if (signal?.aborted) {
                    return abort();
                }

                signal.addEventListener('abort', () => {
                    // Send a request to abort the lifetimer
                    document.dispatchEvent(new CustomEvent('kpxc-passkeys-request', { detail: {
                        action: 'abort',
                    } }));
                }, { once: true });
            }

            ev.addEventListener('kpxc-passkeys-response', listener);

            // Send the request
            document.dispatchEvent(new CustomEvent('kpxc-passkeys-request', { detail: request }));
        });
    };

    /**
     * @returns {Promise<void>}
     */
    const waitForFocus = function () {
        /*
        Some browsers (Firefox, Safari) reject requests to original `navigator.credentials.create/get` if the page
        is out of focus (when the user selects a passkey in KeePassXC-desktop).

        See <https://www.w3.org/TR/webauthn-2/#sctn-abortoperation:~:text=The%20visibility,aborted>

        `document.visibilityState` is not suitable: if the page is visible, but the focus is on another application
        (or DevTools), the request will be rejected.
        */
        return new Promise((resolve) => {
            if (document.hasFocus()) {
                return resolve();
            }
            document.addEventListener(
                'focus',
                () => resolve(),
                { capture: true, passive: true, once: true }
            );
        });
    };

    /**
     * Throws errors to a correct exceptions
     * @param {number} errorCode
     * @param {string} errorMessage
     * @returns {never}
     */
    const throwError = function(errorCode, errorMessage) {
        if ([ PASSKEYS_DOMAIN_RPID_MISMATCH, PASSKEYS_DOMAIN_IS_NOT_VALID ].includes(errorCode)) {
            throw new DOMException(errorMessage, DOMException.SECURITY_ERR);
        }

        if (
            [
                PASSKEYS_NO_SUPPORTED_ALGORITHMS,
                PASSKEYS_EVAL_BY_CREDENTIAL_NOT_SUPPORTED,
                PASSKEYS_EVAL_BY_CREDENTIAL_NOT_EMPTY
            ].includes(errorCode)
        ) {
            throw new DOMException(errorMessage, DOMException.NOT_SUPPORTED_ERR);
        }

        if (errorCode === PASSKEYS_EVAL_BY_CREDENTIAL_NOT_FOUND) {
            throw new DOMException(errorMessage, DOMException.SYNTAX_ERR);
        }

        if ([ PASSKEYS_INVALID_CHALLENGE, PASSKEYS_INVALID_USER_ID ].includes(errorCode)) {
            throw new TypeError(errorMessage);
        }

        if (
            [
                PASSKEYS_NO_LOGINS_FOUND,
                PASSKEYS_CREDENTIAL_IS_EXCLUDED,
                PASSKEYS_REQUEST_CANCELED,
                PASSKEYS_WAIT_FOR_LIFETIMER,
                PASSKEYS_ATTESTATION_NOT_SUPPORTED,
                PASSKEYS_INVALID_URL_PROVIDED,
                PASSKEYS_INVALID_USER_VERIFICATION,
                PASSKEYS_EMPTY_PUBLIC_KEY,
                PASSKEYS_UNKNOWN_ERROR,
                PASSKEYS_ORIGIN_NOT_ALLOWED,
            ].includes(errorCode)
        ) {
            throw new DOMException(errorMessage, 'NotAllowedError');
        }

        throw new DOMException(errorMessage, 'UnknownError');
    };

    const originalCredentials = navigator.credentials;

    const passkeysCredentials = {
        async create(options) {
            if (!options?.publicKey) {
                return null;
            }

            const response = await postMessageToExtension({
                action: 'passkeys_create',
                publicKey: options.publicKey
            }, options?.signal);

            if (!response.publicKey) {
                if (!response.fallback) {
                    throwError(response?.errorCode, response?.errorMessage);
                }
                await waitForFocus();
                return originalCredentials.create(options);
            }

            return createPublicKeyCredential(response.publicKey);
        },
        async get(options) {
            if (!options?.publicKey || options?.mediation === 'silent') {
                return null;
            }

            if (options?.mediation === 'conditional') {
                return originalCredentials.get(options);
            }

            const response = await postMessageToExtension({
                action: 'passkeys_get',
                publicKey: options.publicKey
            }, options?.signal);

            if (!response.publicKey) {
                if (!response.fallback) {
                    throwError(response?.errorCode, response?.errorMessage);
                }
                await waitForFocus();
                return originalCredentials.get(options);
            }

            return createPublicKeyCredential(response.publicKey);
        },
        async store(credential) {
            return originalCredentials.store(credential);
        }
    };

    const isConditionalMediationAvailable = async() => false;
    const isUserVerifyingPlatformAuthenticatorAvailable = async() => true;

    // Overwrite navigator.credentials and PublicKeyCredential.isConditionalMediationAvailable.
    // The latter requires user to select which device to use for authentication, but for now browsers cannot
    // select a software authenticator. This could be removed in the future.
    try {
        Object.defineProperty(navigator, 'credentials', { value: passkeysCredentials });
        if (window.PublicKeyCredential) {
            Object.defineProperty(window.PublicKeyCredential, 'isConditionalMediationAvailable', {
                value: isConditionalMediationAvailable,
            });
            Object.defineProperty(window.PublicKeyCredential, 'isUserVerifyingPlatformAuthenticatorAvailable', {
                value: isUserVerifyingPlatformAuthenticatorAvailable,
            });
        }
    } catch (err) {
        console.log('Cannot override navigator.credentials: ', err);
    }
})();
