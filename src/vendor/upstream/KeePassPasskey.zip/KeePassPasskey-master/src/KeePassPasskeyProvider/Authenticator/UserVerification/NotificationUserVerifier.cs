﻿// SPDX-FileCopyrightText: Copyright (C) 2026 Uwe Koegel
// SPDX-License-Identifier: GPL-3.0-or-later
using System.Globalization;
using Microsoft.Toolkit.Uwp.Notifications;
using Windows.UI.Notifications;
using KeePassPasskeyProvider.Authenticator.Native;
using KeePassPasskeyShared;
using KeePassPasskeyShared.Ipc;
using KeePassPasskeyShared.Settings;

namespace KeePassPasskeyProvider.Authenticator.UserVerification;

internal sealed class NotificationUserVerifier : IUserVerifier
{
	public UserVerificationMode Mode => UserVerificationMode.Notification;

	// Windows toast selection boxes (ToastSelectionBox) are hard-limited to 5 items; adding a 6th
	// throws. We cap what we add and log when there is more so a match-heavy site never fails.
	private const int MaxToastSelectionItems = 5;

	// What the user chose on the registration toast.
	private enum RegistrationAction { Deny, CreateNew, AddToExisting }

	// What the user chose on the entry-picker toast.
	private enum EntryPickerAction { Cancel, CreateNew, UseEntry }

	private static bool NotificationsDisabled()
	{
		var setting = ToastNotificationManagerCompat.CreateToastNotifier().Setting;
		if (setting == NotificationSetting.Enabled) return false;

		Log.Warn($"Notifications disabled ({setting}); use the dialog prompts instead", nameof(NotificationUserVerifier));
		return true;
	}

	public int VerifyForRegistration(RegistrationVerification request, CancellationToken cancellation,
		out DatabaseInfo? selectedDatabase, out EntryTargetInfo? selectedEntry)
	{
		selectedDatabase = null;
		selectedEntry = null;
		if (NotificationsDisabled()) return HResults.E_FAIL;

		string site = request.RpId;
		string user = request.UserName.Length > 0 ? $" for {request.UserName}" : "";
		var candidateEntries = request.CandidateEntries;
		bool hasCandidates = candidateEntries != null && candidateEntries.Count > 0;
		string tag = request.TransactionId.ToString("N");

		var (action, sel) = ShowRegistrationToast(
			title: "Passkey creation requested",
			body: $"Create a passkey{user} on {site}.",
			confirmText: "Create passkey",
			tag: tag,
			databases: request.Databases,
			offerAddToExisting: hasCandidates);

		if (action == RegistrationAction.Deny) return HResults.NTE_USER_CANCELLED;

		if (action == RegistrationAction.AddToExisting)
		{
			var (entryAction, chosen) = ShowEntryPickerToast(
				title: "Choose an entry to save to",
				body: $"Create a passkey for {site}.",
				tag: tag,
				candidates: candidateEntries!);

			if (entryAction == EntryPickerAction.Cancel) return HResults.NTE_USER_CANCELLED;

			if (entryAction == EntryPickerAction.CreateNew)
			{
				selectedDatabase = sel;
				return HResults.S_OK;
			}

			selectedEntry = new EntryTargetInfo { EntryUuid = chosen!.EntryUuid, DatabaseId = chosen.DatabaseId };
			return HResults.S_OK;
		}

		selectedDatabase = sel;
		return HResults.S_OK;
	}

	public int VerifyForSignIn(SignInVerification request, CancellationToken cancellation)
	{
		if (NotificationsDisabled()) return HResults.E_FAIL;

		string user = request.UserName.Length > 0 ? $" as {request.UserName}" : "";
		string hint = !string.IsNullOrEmpty(request.EntryTitle) && request.EntryTitle != request.RpId
			? $"KeePass entry: {request.EntryTitle}" : "";
		return ShowToast(
			title: "Authentication requested",
			body: $"Sign in{user} on {request.RpId}.",
			hint: hint,
			confirmText: "Approve",
			tag: request.TransactionId.ToString("N")) ? HResults.S_OK : HResults.NTE_USER_CANCELLED;
	}

	private static bool ShowToast(string title, string body, string confirmText, string tag, string hint = "")
	{
		int timeoutSeconds = TimeoutSeconds();
		var tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
		var cts = new CancellationTokenSource();

		var builder = new ToastContentBuilder()
			.SetToastScenario(ToastScenario.Alarm)
			.AddAudio(new ToastAudio { Silent = true })
			.AddText(title)
			.AddText(body);

		if (hint.Length > 0)
			builder.AddText(hint);

		AddProgressAndButtons(builder, confirmText);

		var toast = BuildToast(builder, tag, timeoutSeconds);

		toast.Activated += (s, a) =>
		{
			cts.Cancel();
			var args = ((ToastActivatedEventArgs)a).Arguments;
			if (string.IsNullOrEmpty(args)) { tcs.TrySetResult(true); return; }
			var parsed = ToastArguments.Parse(args);
			tcs.TrySetResult(parsed.TryGetValue("action", out var action) && action == "allow");
		};
		toast.Dismissed += (s, a) => { cts.Cancel(); tcs.TrySetResult(false); };
		toast.Failed += (s, a) => { cts.Cancel(); tcs.TrySetResult(false); };

		var notifier = ToastNotificationManagerCompat.CreateToastNotifier();
		notifier.Show(toast);
		RunCountdown(notifier, toast, tag, timeoutSeconds, () => tcs.TrySetResult(false), cts.Token);

		return tcs.Task.GetAwaiter().GetResult();
	}

	private static (RegistrationAction Action, DatabaseInfo? Selected) ShowRegistrationToast(
		string title, string body, string confirmText, string tag,
		IReadOnlyList<DatabaseInfo> databases, bool offerAddToExisting)
	{
		int timeoutSeconds = TimeoutSeconds();
		var tcs = new TaskCompletionSource<(RegistrationAction, DatabaseInfo?)>(TaskCreationOptions.RunContinuationsAsynchronously);
		var cts = new CancellationTokenSource();

		const string selectionBoxId = "dbPicker";

		var builder = new ToastContentBuilder()
			.SetToastScenario(ToastScenario.Alarm)
			.AddAudio(new ToastAudio { Silent = true })
			.AddText(title)
			.AddText(body);

		if (databases.Count > 1)
		{
			var selectionBox = new ToastSelectionBox(selectionBoxId)
			{
				DefaultSelectionBoxItemId = "0",
				Title = "Save to database"
			};
			int dbCount = Math.Min(databases.Count, MaxToastSelectionItems);
			for (int i = 0; i < dbCount; i++)
				selectionBox.Items.Add(new ToastSelectionBoxItem(i.ToString(CultureInfo.InvariantCulture), databases[i].Name));
			if (databases.Count > MaxToastSelectionItems)
				Log.Warn($"Database picker truncated to {MaxToastSelectionItems} of {databases.Count} open databases", nameof(NotificationUserVerifier));
			builder.AddToastInput(selectionBox);
		}

		builder.AddVisualChild(ProgressBar())
			.AddButton(new ToastButton()
				.SetContent(confirmText)
				.AddArgument("action", "allow"));

		if (offerAddToExisting)
			builder.AddButton(new ToastButton()
				.SetContent("Add to existing")
				.AddArgument("action", "existing"));

		builder.AddButton(new ToastButton()
			.SetContent("Cancel")
			.AddArgument("action", "deny"));

		var toast = BuildToast(builder, tag, timeoutSeconds);

		toast.Activated += (s, a) =>
		{
			cts.Cancel();
			var args = ((ToastActivatedEventArgs)a).Arguments;
			var inputs = ((ToastActivatedEventArgs)a).UserInput;
			string? indexStr = inputs.ContainsKey(selectionBoxId) ? inputs[selectionBoxId]?.ToString() : "0";
			int idx = int.TryParse(indexStr, NumberStyles.Integer, CultureInfo.InvariantCulture, out int idxParsed) && idxParsed >= 0 && idxParsed < databases.Count ? idxParsed : 0;
			DatabaseInfo selectedDb = databases[idx];
			var selected = new DatabaseInfo { Id = selectedDb.Id, Name = selectedDb.Name };

			var parsed = string.IsNullOrEmpty(args) ? null : ToastArguments.Parse(args);
			string action = parsed != null && parsed.TryGetValue("action", out var act) ? act : "allow";
			var result = action switch
			{
				"existing" => RegistrationAction.AddToExisting,
				"deny" => RegistrationAction.Deny,
				_ => RegistrationAction.CreateNew,
			};
			tcs.TrySetResult((result, selected));
		};
		toast.Dismissed += (s, a) => { cts.Cancel(); tcs.TrySetResult((RegistrationAction.Deny, null)); };
		toast.Failed += (s, a) => { cts.Cancel(); tcs.TrySetResult((RegistrationAction.Deny, null)); };

		var notifier = ToastNotificationManagerCompat.CreateToastNotifier();
		notifier.Show(toast);
		RunCountdown(notifier, toast, tag, timeoutSeconds, () => tcs.TrySetResult((RegistrationAction.Deny, null)), cts.Token);

		return tcs.Task.GetAwaiter().GetResult();
	}

	// Second toast: pick which existing entry to attach the passkey to. Modeled on the database
	// picker. Entries that already hold a passkey are labelled so overwriting is an informed choice.
	private static (EntryPickerAction Action, EntryMatchInfo? Entry) ShowEntryPickerToast(
		string title, string body, string tag, IReadOnlyList<EntryMatchInfo> candidates)
	{
		int timeoutSeconds = TimeoutSeconds();
		var tcs = new TaskCompletionSource<(EntryPickerAction, EntryMatchInfo?)>(TaskCreationOptions.RunContinuationsAsynchronously);
		var cts = new CancellationTokenSource();

		const string selectionBoxId = "entryPicker";
		bool showDbName = false;
		for (int i = 1; i < candidates.Count; i++)
			if (candidates[i].DatabaseId != candidates[0].DatabaseId) { showDbName = true; break; }

		int shown = Math.Min(candidates.Count, MaxToastSelectionItems);
		bool truncated = candidates.Count > MaxToastSelectionItems;

		var builder = new ToastContentBuilder()
			.SetToastScenario(ToastScenario.Alarm)
			.AddAudio(new ToastAudio { Silent = true })
			.AddText(title)
			.AddText(body);

		if (truncated)
			builder.AddText($"Showing {shown} of {candidates.Count} matching entries.");

		var selectionBox = new ToastSelectionBox(selectionBoxId)
		{
			DefaultSelectionBoxItemId = "0",
			Title = "Save to entry"
		};
		for (int i = 0; i < shown; i++)
			selectionBox.Items.Add(new ToastSelectionBoxItem(i.ToString(CultureInfo.InvariantCulture), EntryLabel(candidates[i], showDbName)));
		if (truncated)
			Log.Warn($"Entry picker truncated to {MaxToastSelectionItems} of {candidates.Count} matching entries", nameof(NotificationUserVerifier));
		builder.AddToastInput(selectionBox);

		builder.AddVisualChild(ProgressBar())
			.AddButton(new ToastButton()
				.SetContent("Save to entry")
				.AddArgument("action", "allow"))
			.AddButton(new ToastButton()
				.SetContent("Create new")
				.AddArgument("action", "new"))
			.AddButton(new ToastButton()
				.SetContent("Cancel")
				.AddArgument("action", "deny"));

		var toast = BuildToast(builder, tag, timeoutSeconds);

		toast.Activated += (s, a) =>
		{
			cts.Cancel();
			var args = ((ToastActivatedEventArgs)a).Arguments;
			var inputs = ((ToastActivatedEventArgs)a).UserInput;
			var parsed = string.IsNullOrEmpty(args) ? null : ToastArguments.Parse(args);
			string action = parsed != null && parsed.TryGetValue("action", out var act) ? act : "allow";

			if (action == "deny") { tcs.TrySetResult((EntryPickerAction.Cancel, null)); return; }
			if (action == "new") { tcs.TrySetResult((EntryPickerAction.CreateNew, null)); return; }

			string? indexStr = inputs.ContainsKey(selectionBoxId) ? inputs[selectionBoxId]?.ToString() : "0";
			int idx = int.TryParse(indexStr, NumberStyles.Integer, CultureInfo.InvariantCulture, out int idxParsed) && idxParsed >= 0 && idxParsed < candidates.Count ? idxParsed : 0;
			tcs.TrySetResult((EntryPickerAction.UseEntry, candidates[idx]));
		};
		toast.Dismissed += (s, a) => { cts.Cancel(); tcs.TrySetResult((EntryPickerAction.Cancel, null)); };
		toast.Failed += (s, a) => { cts.Cancel(); tcs.TrySetResult((EntryPickerAction.Cancel, null)); };

		var notifier = ToastNotificationManagerCompat.CreateToastNotifier();
		notifier.Show(toast);
		RunCountdown(notifier, toast, tag, timeoutSeconds, () => tcs.TrySetResult((EntryPickerAction.Cancel, null)), cts.Token);

		return tcs.Task.GetAwaiter().GetResult();
	}

	private static string EntryLabel(EntryMatchInfo entry, bool showDbName)
	{
		string title = string.IsNullOrEmpty(entry.Title) ? "(untitled)" : entry.Title;
		if (showDbName && !string.IsNullOrEmpty(entry.DatabaseName))
			title = $"{entry.DatabaseName}: {title}";

		var tags = new List<string>(2);
		if (entry.IsSelected) tags.Add("selected");
		if (entry.HasPasskey) tags.Add("overwrite passkey");
		return tags.Count > 0 ? $"{title} [{string.Join(", ", tags)}]" : title;
	}

	private static int TimeoutSeconds()
		=> KeePassPasskeySettings.Current.NotificationVerificationTimeoutMilliseconds / 1000;

	private static AdaptiveProgressBar ProgressBar() => new AdaptiveProgressBar
	{
		Value = new BindableProgressBarValue("progress"),
		ValueStringOverride = char.ConvertFromUtf32(0x2003), // U+2003 EM SPACE (hides % value)
		Status = new BindableString("statusText"),
	};

	private static void AddProgressAndButtons(ToastContentBuilder builder, string confirmText)
		=> builder.AddVisualChild(ProgressBar())
			.AddButton(new ToastButton().SetContent(confirmText).AddArgument("action", "allow"))
			.AddButton(new ToastButton().SetContent("Cancel").AddArgument("action", "deny"));

	private static ToastNotification BuildToast(ToastContentBuilder builder, string tag, int timeoutSeconds)
	{
		var initialData = new NotificationData();
		initialData.Values["progress"] = "0";
		initialData.Values["statusText"] = $"Cancelling in {timeoutSeconds}s";

		return new ToastNotification(builder.GetXml())
		{
			Tag = tag,
			Data = initialData,
			ExpirationTime = DateTimeOffset.Now.AddSeconds(timeoutSeconds),
		};
	}

	// Drives the countdown progress bar and hides the toast + fires onTimeout when it elapses.
	// Cancelled (via the token) as soon as the user acts on the toast.
	private static void RunCountdown(ToastNotifierCompat notifier, ToastNotification toast, string tag,
		int timeoutSeconds, Action onTimeout, CancellationToken token)
	{
		_ = Task.Run(async () =>
		{
			for (int remaining = timeoutSeconds - 1; remaining >= 0; remaining--)
			{
				try { await Task.Delay(1000, token).ConfigureAwait(false); }
				catch (OperationCanceledException) { return; }

				if (token.IsCancellationRequested) return;

				int elapsed = timeoutSeconds - remaining;
				var update = new NotificationData();
				update.Values["progress"] = FormattableString.Invariant($"{(double)elapsed / timeoutSeconds}");
				update.Values["statusText"] = $"Cancelling in {remaining}s";
				notifier.Update(update, tag);
			}
			notifier.Hide(toast);
			onTimeout();
		}, token);
	}
}
